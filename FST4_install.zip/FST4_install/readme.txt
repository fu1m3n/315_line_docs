========
FST 4.02
========

Release Notes

                                                        March 13th, 2001

Here is release 4.02.21 of FST for Windows. This is the second product
release on CD-ROM of the FST for Windows (FST4).


Installation of the FST 4.02.21
-------------------------------

When your CD drive has Auto Insert Notification enabled, a menu will appear
with the option to install FST4.

You can also manually initiate the installation by starting SETUP.EXE in
the \INSTALL subdirectory.

This version uses an InstallShield setup which will add appropriate entries
in the Start menu for you.

If you do not have the permission to install programs on your PC, this
version can also be installed from the self-extracting file FST40221.EXE in
the \INSTALL subdirectory. It will try to create a directory/folder
C:\FST40221. You can change this during the installation to whatever you
like.

This FST 4 does NOT touch any of your system INI files (WIN.INI,
SYSTEM.INI, ...) It will NOT replace any system library (xxx.DLL, xxx.VXD,
...) And it will currently NOT touch the registry in your box (except for
the Uninstall information when using the InstallShield setup).

Also install the tools in the \TOOLS folder of the CD-ROM if required.

Some modules and drivers that have been part of former FST releases can be
found in the \OLDLIB folder of the CD-ROM. Use these drivers only if
required for old projects. Please regard the important information in the
README files for the individual drivers.


Uninstalling
------------

If you installed FST 4 using the InstallShield setup, the uninstall
information is stored in the Windows registry. FST 4 can be removed from
your PC using the Windows Control Panel (Software).

To get rid of any FST 4 version installed from a self-extracting zip file
simply remove the installation directory/folder, usually C:\FST40220, and
all its subdirectories/folders.


Known Problems
--------------

ONLINE HELP
     The FST 4 Online Help uses the HTML Help viewer. This requires that
     you have Internet Explorer 4 or higher installed.
     The HTML Help Installation and Update package (HHUPD.EXE in the
     \INSTALL folder) will update your installation to the latest version
     (on a Windows NT system this requires that you have administrator
     privileges). The update will not be executed if you already have a
     newer version of HTML Help installed.
     Windows 2000 users should not run the HTML Help Installation and
     Update Package. Help component updates are provided via Windows
     service packs.
     For more information see http://www.microsoft.com.
     If you do not want to use Internet Explorer the contents of the FST 4
     Online Help are also available in PDF format in the folder \MANUALS of
     the CD-ROM.
     If you want to make a printout of the entire Online Help it is
     suggested to use the PDF version.

EXTERNAL TOOLS
     This version of FST 4 still uses some DOS programs, e.g. the OWS
     tools. Some of these programs will not work correctly if the current
     FST project is stored in a path that is not according to DOS rules,
     i.e. no spaces, max. 8+3 characters per folder name. Please use a
     project path that is according to DOS rules if you want to use these
     programs.
     On Windows 2000 all DOS tools are troublesome and the mouse does not
     work.
     It is currently not possible to use Ethernet for the online features
     of the fieldbus configurators.

TCP/IP
     Before you can use TCP/IP for programming (download) and online
     displays you once have to download a project including the TCPIP
     driver via the RS232 connection.
     When using TCP/IP for downloading a project, please make sure not to
     select the option "Delete project before download" in the Controller
     Settings, since this will also stop the TCP/IP driver.
     When setting a password for the controller this will prevent
     modifications for both, serial and TCP/IP access.

IO1x/IO4x
     Use the versions with a suffix "N" together with kernel 2.23.01 or
     later only. The versions without "N" will work with any kernel 2.2x,
     but may block the PLC cycle on defective or missing hardware.
     Therefore they are no longer include in the FST standard installation.
     If required you can install them from the folder \OLDLIB of the
     installation CD-ROM. If an upgrade of your CPU module is required
     please contact your local Festo dealer.

HC1X + RTC + DRAD + FESTOBUS
     When the HC1X is equipped with a ZL16/ZL17 chip, accessing the
     real-time clock the FST modules F1x will cause the Festo fieldbus IO
     update to stop after some time. The problem is under investigation.

HC2X + AS-INTERFACE (CP96)
     Only up to two CP96 modules with the switch settings KSW=1 and KSW=4
     can be used together with the HC20 CPU. The switch positions KSW=2 and
     KSW=3 lead to memory conflicts.

HC2X + OM22 PLC SAFETY
     Only IO modules OM22 with a version of P16 or higher can be operated
     in PLC Safety mode on the HC20 CPU.

FIND & REPLACE
     When using the Find or Replace function of the STL Editor, the
     Allocation List Editor or the Message Window please close the
     Find/Replace dialog box before closing the editor/message window from
     which you opened the Find/Replace dialog. The dialog box will only
     work for the editor window from which it was opened. If you want to
     search in another window please close the dialog box and reopen it
     again after you have selected the other edior window.

STARTUP DRIVE
     Be careful when you change the drive for the STARTUP.BAT file
     (Controller Settings - Drives). Make sure that the AUTOEXEC.BAT of the
     controller looks for a STARTUP.BAT on that drive and delete all
     STARTUP.BAT files on any other drives (using the Filetransfer tool).
     For information on possible STARTUP.BAT locations consult the manual
     or online help (chapter PLC operating system - miscellaneus). Usually
     it is best to keep the default for each controller type: FECs: B: -
     HC0X: B: - HC1X: C: - HC20: C:

FILE HANDLING WITH FLOPPY DISK
     If no floppy in the drive and you try to access it with the file
     handling modules no error message is returned.

ONLINE
     If you have problems with the online connection you should set the
     baudrate to 2400. This is often the case when Festo fieldbus is active
     or the CPU is busy with communication, e.g. on other serial ports.
     Avoid long steps in control programs that are executed frequently
     since this will shorten the time slot for CI communication. Please
     note that calling CFMs may take a considerable amount of time,
     especially if several CFMs are called in sequence in the same step,
     e.g. AMXX. Calling CMPs is uncritical since a task switch (invisible
     step) is inserted after each call automatically.

FIRST LOGIN TO NEW HC1X
     If you have problems connection to a new HC1X CPU try using a baudrate
     different from 9600. If you are not successful try the following:
       1. Exit FST
       2. Reboot the HC1X
       3. Execute SENDBRK.EXE that can be found in the directory where you
          have installed FST 4
       4. Choose the COM port you are using for FST
       5. Start FST and try again (do not reboot the HC1X)
     Once you have successfully loaded a FST project the problem no longer
     exists since then FST is directly started when the CPU is booted.


What is new compared to FST 4.01.16
-----------------------------------

   * It is now possible to download the project without updating the driver
     files. This feature an be useful if making minor changes to old
     projects.
   * Controllers of the FEC Standard family are now supported.
   * FST 4 is now also available in German.
   * In the English version the user can select if he wants to use the
     keyword ELSE instead of OTHRW in Statementlist.
   * In the driver options dialog is now a help button to open the driver's
     chapter in the online help.
   * New and imported programs or modules are now selecetd for download by
     default.
   * When importing modules from the library more than one module can be
     selected at the same time.
   * Modules can now be imported from any directory if required (this is a
     useful feature for module developers).
   * New tab in the Online Display for Strings.
   * Plattform dependent choices for controller settings.
   * Show COM port or IP address in title bar of the STL Online window.
   * The local IO for FEC and HC0X controllers are now automatically added
     to the IO configuration by default for new projects.


Bug fixes since FST 4.01.16
---------------------------

   * Longer timeouts for CI communication allow connection to busy CPUs.
   * Out of range constants in STL are no longer ignored.
   * Allow to switch program status in online display even with fast update
     speed.
   * Direct printing of source code programs that are not selected for
     download is now possible.
   * Sorted printout of source code and compilation log.
   * Correct display of large timer values.
   * Regard special case for EW in online display user defined tab.
   * Enable switch selection for IO modules only if more than one choice
     possible.
   * Sorted print out of cross reference list.


What is new compared to FST 3
-----------------------------

   * Note! Changed run-time code.

     FST 4 now compiles code for CFMs which do NOT include a task switch.
     For this to work, CFMs no longer may have STEPs. This gives you a
     chance to have simple and direct "subroutines". The old FST 3.x method
     prohibited this entirely. The behaviour of CMPs haven't been touched.

     In most cases you cannot see the difference at all. If you have used
     CFMs with steps change them to CMPs - and (in most cases) forget this
     issue.

     The new rules are easy to remember:

        o A program may call CMPs and CFMs (unchanged),
          calling a CMP always include a task switch (unchanged),
          the called CMP may have steps (unchanged),
          calling a CFM will not cause a task switch (new).
        o A CMP may call CFMs (unchanged),
          but a CMP may NOT call another CMP (unchanged).
        o A CFM may call other CFMs (new),
          but a CFM may NOT call a CMP (new).

     In a diagram the rule looks as follows:

                 Program  -- calls -->  CFMs
                          -- calls -->  CMPs
                 CMP      -- calls -->  CFMs
                 CFM      -- calls -->  CFMs

     The FST kernel (PLC operating system) from version 2.24.3 will check
     this at run-time.

     If you get error 36, check which function module you are calling in
     the step where the error occurred. Rename this module as a CMP and
     change your programs accordingly.

     The modules FWRITSTR and FREADSTR of the FST runtime library are using
     steps and can be used as CMPs only.

   * Mr. Westrik from Festo-NL has contributed the TCP/IP part of the FST 4
     software. After a first download of the FST TCP/IP driver, it is also
     possible to use TCP/IP for all online tasks - from CI commands to
     downloading. Simply change the settings in "Extras >> FST Preferences
     >> Communication port".

   * The communication method has changed significantly. Well, we still use
     the old fashioned CI but we did further analysis on the
     implementation. The obvious situation where you will see this is a
     faster login to the remote controller.

   * Make and Download are separated, a Build All is also available.

     "Make" will only compile and link what has been changed. This is what
     you are used to with FST 3.x. "Build", contrary to "Make," will
     compile and link everything. Our "Make" is pretty clever. So you don't
     need the "Build." But whenever in doubt - it's available.

   * There is a project specific IPC controller setting which lets you
     automatically stop and unload a project on the IPC controller when
     downloading.

   * Run-time options are selectable one by one instead of two
     pre-configured run-time modes ("Machine Mode" and "Unit Mode" in FST
     3.x notion.)

   * An AUTOSTART run-time option is available.

   * All kinds of online displays can be used at the same time, have the
     online display in one window, a CI terminal in another window and STL
     online in one or more additional windows. Then try to transfer a file
     to or from the controller.


Conversion of FST 3.x Projects to FST 4.x
-----------------------------------------

The conversion program FST3TO4.EXE is accessible by menu entry "Extras >>
Convert FST 3.x Projects". Just select the right path (of FST IPC 3.x or
the FST IPC 3.x project path) and select a project to convert.

It is recommended to rebuild the entire project by selecting menue item
"Project >> Build Project" or click the appropriate toolbar button.


What is still incomplete
------------------------

The "Tip of the Day" is just a start. It is not a very powerful wizard.
Ideas and new tips are welcome.


What is still missing
---------------------

Here is a list of things which are not yet implemented in this version:

   * Ladder diagram
   * Windows version of OWS


The following new features/bug fixes require an update of the kernel
--------------------------------------------------------------------
version (firmware)
------------------

   * get runtime error when calling CFMs with steps (2.24.03)
   * version checking when starting STL online (2.24.02)
   * improved PLC Safety method (2.24.02)
   * online display of counters (2.23.03)
   * IO1x/IO4x (2.23.01)

You can check the detailed version with the CI command "L!". If this
results in "ACCESS ERROR" you have kernel version 2.22 or less.

If you an upgrade of your CPU module is required please contact your local
Festo dealer.


History
-------

2001/ 3/13    4.02.21    cd-rom "Edition April 2001"
2000/ 8/14    4.01.16    cd-rom "Edition August 2000"
